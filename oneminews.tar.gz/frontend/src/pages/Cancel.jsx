export default function Cancel() {
  return (
    <div style={{ padding: "2rem", textAlign: "center", color: "#f00" }}>
      <h1>⚠️ Subscription cancelled</h1>
      <p>You can try again anytime.</p>
    </div>
  );
}